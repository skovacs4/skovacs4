% Sentiment Analysis on Twitter data with NLP
% @Stefan Kovacs


% a structure to store the twitter credentials needed for accessing the
% Twitter Dev API
credentials = struct('ConsumerKey','rjMnavapX3ajlDakl52CBNd1L',...
    'ConsumerSecret','itFWeUXoHPMsDfcf0kcAAxr6MqTYActlMYhGxP6IhyrLNHRqOU',...
    'AccessToken','1321983477177344000-b5t4yLUnDZKriwUWaEQLNoXX9nlqsE',...
    'AccessTokenSecret','7RUkF4N1FdzeaRhYKsYVawb4jO9raugn00Tya4y396hpG');

% Twitty object
addpath twitty_1.1.1; % Twitty
addpath parse_json; % Twitty's default json parser
addpath jsonlab; % I prefer JSONlab, however. 

twt = twitty(credentials); % instantiate object 
twt.jsonParser = @loadjson; % specify parser

% search for words
rockstar = twt.search('rockstar','count',100,'include_entities','true','lang','en');
gta = twt.search('gta','count',100,'include_entities','true','lang','en');
both = twt.search('rockstar gta','count',100,'include_entities','true','lang','en');

% data for text processing
newFile = 'AFINN/AFINN-111.txt';
stopwordsLink ='http://www.textfixer.com/resources/common-english-words.txt';
% load saved data
load amazonHachette.mat

% utility method
[rockstarUsers,rockstarTweets] = processTweets.extract(rockstar);
% sentiment scores|
rockstarTweets.Sentiment = processTweets.scoreSentiment(rockstarTweets, ...
    newFile,stopwordsLink);

% repeat the process for gta
[gtaUsers,gtaTweets] = processTweets.extract(gta);
gtaTweets.Sentiment = processTweets.scoreSentiment(gtaTweets, ...
    newFile,stopwordsLink);

% repeat the process for tweets containing both
[bothUsers,bothTweets] = processTweets.extract(both);
bothTweets.Sentiment = processTweets.scoreSentiment(bothTweets, ...
    newFile,stopwordsLink);

% calculate and print NSRs
rockstarNSR = (sum(rockstarTweets.Sentiment>=0) ...
    -sum(rockstarTweets.Sentiment<0)) ...
    /height(rockstarTweets);
gtaNSR = (sum(gtaTweets.Sentiment>=0) ...
    -sum(gtaTweets.Sentiment<0)) ...
    /height(gtaTweets);
bothNSR = (sum(bothTweets.Sentiment>=0) ...
    -sum(bothTweets.Sentiment<0)) ...
    /height(bothTweets);
fprintf('Rockstar NSR  :  %.2f\n',rockstarNSR)
fprintf('GTA NSR:  %.2f\n',gtaNSR)
fprintf('Both NSR    : %.2f\n\n',bothNSR)

% plot the sentiment histogram of two brands
binranges = min([rockstarTweets.Sentiment; ...
    gtaTweets.Sentiment; ...
    bothTweets.Sentiment]): ...
    max([rockstarTweets.Sentiment; ...
    gtaTweets.Sentiment; ...
    bothTweets.Sentiment]);
bincounts = [histcounts(rockstarTweets.Sentiment,binranges)...
    histcounts(gtaTweets.Sentiment,binranges)...
    histcounts(bothTweets.Sentiment,binranges)];
figure
bar(binranges,bincounts,'hist')
legend('Rockstar','GTA','Both','Location','Best')
title('Sentiment Distribution of 100 Tweets')
xlabel('Sentiment Score')
ylabel('# Tweets')

%% Processing Tweets for Content Visualization
% |processTweets| also has a function
% |tokenize| that parses tweets to calculate the word count.

% tokenize tweets with |tokenize| method of |processTweets|
[words, dictionary] = processTweets.tokenize(bothTweets,stopwordsLink);
% create a dictionary of unique words
dictionary = unique(dictionary);
% create a word count matrix
[~,tdf] = processTweets.getTFIDF(words,dictionary);

% plot the word count
figure
plot(1:length(dictionary),sum(tdf),'b.')
xlabel('Word Indices')
ylabel('Word Count')
title('Words contained in the tweets')

% annotate high frequency words
annotated = find(sum(tdf)>= 10);
jitter = 6*rand(1,length(annotated))-3;
for i = 1:length(annotated)
    text(annotated(i)+3, ...
        sum(tdf(:,annotated(i)))+jitter(i),dictionary{annotated(i)})
end

% sort the user table by follower count in descending order
[~,order] = sortrows(bothUsers,'Followers','descend');
% select top 5 users
top5users = bothUsers(order(1:5),[3,1,5]);
% add a column to store the profile
top5users.Description = repmat({''},height(top5users),1);
% retrieve user profile for each user
for i = 1:5
    userInfo = twt.usersShow('user_id', top5users.Id(i));
    if ~isempty(userInfo{1}.description)
        top5users.Description{i} = userInfo{1}.description;
    end
end
% print the result
disp(top5users(:,2:end))

% reload the previously saved search result for 4 trending topics in the UK
load('uk_data.mat')

% plot
figure
for i = 1:4
    % process tweets
    [users,tweets] = processTweets.extract(uk_data(i).statuses);
    
    % get who are mentioned in retweets
    retweeted = tweets.Mentions(tweets.isRT);
    retweeted = retweeted(~cellfun('isempty',retweeted));
    [screen_names,~,idx] = unique(retweeted);
    count = accumarray(idx,1);
    retweeted = table(screen_names,count,'VariableNames',{'Screen_Name','Count'});

    % get the users who were mentioned in retweets
    match = ismember(users.Screen_Name,retweeted.Screen_Name);
    retweetedUsers = sortrows(users(match,:),'Screen_Name');
    match = ismember(retweeted.Screen_Name,retweetedUsers.Screen_Name);
    retweetedUsers.Retweeted_Count = retweeted.Count(match);
    [~,order] = sortrows(retweetedUsers,'Retweeted_Count','descend');
    
    % plot each topic
    subplot(2,2,i)
    scatter(retweetedUsers.Followers(order),...
        retweetedUsers.Retweeted_Count(order),retweetedUsers.Freq(order)*50,...
        retweetedUsers.Freq(order),'fill')

    if ismember(i, [1,2])
        ylim([-20,90]); xpos = 2; ypos1 = 50; ypos2 = 40;
    elseif i == 3
        ylim([-1,7])
        xlabel('Follower Count (Log Scale)')
        xpos = 1010; ypos1 = 0; ypos2 = -1;
    else
        ylim([-5,23])
        xlabel('Follower Count (Log Scale)')
        xpos = 110; ypos1 = 20; ypos2 = 17;
    end
    
    % set x axis to log scale
    set(gca, 'XScale', 'log')
    
    if ismember(i, [1,3])
        ylabel('Retweeted Count')
    end
    title(sprintf('UK Tweets for: "%s"',uk_data(i).query.name))
end


processTweets.saveEdgeList(uk_data(1).statuses,'edgeList.csv');




